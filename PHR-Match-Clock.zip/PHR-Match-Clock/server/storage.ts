import { db } from "./db";
import {
  matches,
  users,
  type Match,
  type InsertMatch,
  type UpdateMatchRequest,
  type User
} from "@shared/schema";
import { eq, desc, or } from "drizzle-orm";

export interface IStorage {
  // Match operations
  getMatches(): Promise<Match[]>;
  getMatch(id: number): Promise<Match | undefined>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatch(id: number, updates: UpdateMatchRequest): Promise<Match>;
  deleteMatch(id: number): Promise<void>;
  
  // User operations (for listing players)
  getUsers(): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  async getMatches(): Promise<Match[]> {
    return await db.select().from(matches).orderBy(desc(matches.startTime));
  }

  async getMatch(id: number): Promise<Match | undefined> {
    const [match] = await db.select().from(matches).where(eq(matches.id, id));
    return match;
  }

  async createMatch(match: InsertMatch): Promise<Match> {
    const [newMatch] = await db.insert(matches).values(match).returning();
    return newMatch;
  }

  async updateMatch(id: number, updates: UpdateMatchRequest): Promise<Match> {
    const [updated] = await db
      .update(matches)
      .set({
        ...updates,
        lastActionAt: new Date(), // Always update timestamp on action
      })
      .where(eq(matches.id, id))
      .returning();
    return updated;
  }

  async deleteMatch(id: number): Promise<void> {
    await db.delete(matches).where(eq(matches.id, id));
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
}

export const storage = new DatabaseStorage();
