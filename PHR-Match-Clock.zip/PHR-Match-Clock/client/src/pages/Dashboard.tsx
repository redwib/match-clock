import { useMatches, useDeleteMatch } from "@/hooks/use-matches";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Plus, ChevronRight, Clock, Trophy, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: matches, isLoading } = useMatches();
  const deleteMatch = useDeleteMatch();

  if (isLoading) {
    return (
      <div className="space-y-4 animate-pulse">
        <div className="h-48 bg-card rounded-3xl w-full" />
        <div className="h-24 bg-card rounded-2xl w-full" />
        <div className="h-24 bg-card rounded-2xl w-full" />
      </div>
    );
  }

  const activeMatches = matches?.filter(m => m.status === 'ongoing') || [];
  const historyMatches = matches?.filter(m => m.status === 'finished').sort((a, b) => 
    new Date(b.endTime || 0).getTime() - new Date(a.endTime || 0).getTime()
  ) || [];

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, {user?.firstName}.</p>
        </div>
        <Button asChild size="lg" className="rounded-full shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all">
          <Link href="/match/new">
            <Plus className="w-5 h-5 mr-2" /> New Match
          </Link>
        </Button>
      </div>

      {/* Active Matches */}
      {activeMatches.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold">In Progress</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeMatches.map((match) => (
              <Link key={match.id} href={`/match/${match.id}`} className="block group">
                <div className="bg-card border border-border rounded-2xl p-6 hover:border-primary/50 transition-all hover:shadow-lg hover:-translate-y-1 h-full flex flex-col">
                  <div className="flex justify-between items-center mb-6">
                    <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider animate-pulse">
                      Live
                    </span>
                    <span className="text-xs text-muted-foreground font-mono">
                      {formatDistanceToNow(new Date(match.startTime || new Date()), { addSuffix: true })}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center flex-1">
                    <div className="text-center flex-1">
                      <div className="text-3xl font-bold font-digital mb-1">{match.player1Score}</div>
                      <div className="text-sm font-medium truncate px-2">{match.player1?.firstName}</div>
                    </div>
                    <div className="text-muted-foreground font-display text-xl px-4">VS</div>
                    <div className="text-center flex-1">
                      <div className="text-3xl font-bold font-digital mb-1">{match.player2Score}</div>
                      <div className="text-sm font-medium truncate px-2">{match.player2?.firstName}</div>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end">
                    <span className="text-primary text-sm font-medium group-hover:translate-x-1 transition-transform flex items-center">
                      Resume Match <ChevronRight className="w-4 h-4 ml-1" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Match History */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-muted-foreground" />
          <h2 className="text-xl font-bold text-muted-foreground">Recent History</h2>
        </div>
        
        {historyMatches.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-border rounded-3xl">
            <p className="text-muted-foreground">No completed matches yet.</p>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-3xl overflow-hidden">
            {historyMatches.map((match, i) => (
              <div 
                key={match.id}
                className={`p-6 flex flex-col md:flex-row items-center gap-6 hover:bg-white/5 transition-colors ${i !== historyMatches.length - 1 ? 'border-b border-border' : ''}`}
              >
                <div className="flex-1 w-full md:w-auto flex justify-between md:justify-start items-center gap-8">
                  <div className="flex items-center gap-4 flex-1 justify-end">
                    <span className={`font-medium ${match.winnerId === match.player1Id ? 'text-primary' : ''}`}>
                      {match.player1?.firstName} {match.player1?.lastName}
                    </span>
                    <span className="text-2xl font-bold font-digital w-8 text-center">{match.player1Score}</span>
                  </div>
                  
                  <span className="text-muted-foreground text-sm font-mono">-</span>
                  
                  <div className="flex items-center gap-4 flex-1">
                    <span className="text-2xl font-bold font-digital w-8 text-center">{match.player2Score}</span>
                    <span className={`font-medium ${match.winnerId === match.player2Id ? 'text-primary' : ''}`}>
                      {match.player2?.firstName} {match.player2?.lastName}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
                  <span className="text-sm text-muted-foreground whitespace-nowrap">
                    {formatDistanceToNow(new Date(match.endTime!), { addSuffix: true })}
                  </span>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="hover:text-destructive hover:bg-destructive/10">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete match record?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently remove this match from your history.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => deleteMatch.mutate(match.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
