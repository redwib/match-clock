import { Button } from "@/components/ui/button";
import { ArrowRight, Trophy, Clock, Zap } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Landing() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && user) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) return <div className="min-h-screen bg-background flex items-center justify-center"><div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" /></div>;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <nav className="p-6 flex justify-between items-center max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-primary-foreground">
            <Trophy className="w-5 h-5" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight">CUE<span className="text-primary">MASTER</span></span>
        </div>
        <Button asChild variant="outline" className="rounded-full px-6">
          <a href="/api/login">Log In</a>
        </Button>
      </nav>

      <main className="flex-1 flex flex-col items-center justify-center px-4 text-center max-w-5xl mx-auto w-full">
        <div className="space-y-6 mb-16 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium border border-primary/20">
            <Zap className="w-4 h-4 fill-primary" />
            <span>The ultimate pool match tracker</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold font-display leading-tight tracking-tight">
            Elevate Your <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-green-400 to-emerald-500">
              Pool Game
            </span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Track scores, monitor alternating breaks, and keep time with precision. 
            The professional tool for serious pool players.
          </p>

          <div className="pt-4 flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="h-14 px-8 rounded-full text-lg shadow-xl shadow-primary/25 hover:scale-105 transition-transform">
              <a href="/api/login">
                Get Started <ArrowRight className="ml-2 w-5 h-5" />
              </a>
            </Button>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-4xl animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-300">
          {[
            { 
              icon: Trophy, 
              title: "Live Scoring", 
              desc: "Real-time score tracking with accessible, high-contrast digital displays." 
            },
            { 
              icon: Clock, 
              title: "Precision Timers", 
              desc: "Integrated shot clock and match timer to keep the pace professional." 
            },
            { 
              icon: Zap, 
              title: "Break Tracking", 
              desc: "Smart alternating break indicators that update automatically as you play." 
            }
          ].map((feature, i) => (
            <div key={i} className="bg-card/50 backdrop-blur-sm p-6 rounded-3xl border border-white/5 hover:border-primary/50 transition-colors group text-left">
              <div className="w-12 h-12 rounded-2xl bg-muted group-hover:bg-primary/20 flex items-center justify-center text-foreground group-hover:text-primary transition-colors mb-4">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.desc}</p>
            </div>
          ))}
        </div>
      </main>

      <footer className="py-8 text-center text-muted-foreground text-sm border-t border-white/5">
        <p>© 2024 CueMaster. All rights reserved.</p>
      </footer>
    </div>
  );
}
