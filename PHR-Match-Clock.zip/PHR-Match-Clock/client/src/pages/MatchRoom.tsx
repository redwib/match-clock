import { useMatch, useUpdateMatch } from "@/hooks/use-matches";
import { useParams, Link } from "wouter";
import { Loader2, ArrowLeft, Trophy, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScoreCard } from "@/components/match/ScoreCard";
import { MatchClock } from "@/components/match/MatchClock";
import { ShotClock } from "@/components/match/ShotClock";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function MatchRoom() {
  const { id } = useParams<{ id: string }>();
  const matchId = parseInt(id);
  const { data: match, isLoading } = useMatch(matchId);
  const updateMatch = useUpdateMatch();
  const { toast } = useToast();

  if (isLoading || !match) {
    return <div className="h-screen flex items-center justify-center"><Loader2 className="w-10 h-10 animate-spin text-primary" /></div>;
  }

  const isFinished = match.status === 'finished';
  const isClockZero = match.elapsedSeconds <= 0;

  const handleScoreChange = (player: 'player1' | 'player2', change: number) => {
    if (isFinished) return;

    const currentScore = player === 'player1' ? match.player1Score : match.player2Score;
    const newScore = Math.max(-4, currentScore + change);

    // Logic: If score increased, toggle breaker
    let nextBreakerId = match.currentBreakerId;
    if (change > 0) {
      nextBreakerId = match.currentBreakerId === match.player1Id 
        ? match.player2Id 
        : match.player1Id;
    }
    
    updateMatch.mutate({
      id: matchId,
      updates: {
        [`${player}Score`]: newScore,
        currentBreakerId: nextBreakerId
      }
    });
  };

  const handleFinishMatch = (winnerId: string) => {
    updateMatch.mutate({
      id: matchId,
      updates: {
        status: 'finished',
        winnerId: winnerId,
        endTime: new Date().toISOString() as any,
        isPaused: true // Stop timer
      }
    }, {
      onSuccess: () => {
        toast({ title: "Match Finished!", description: "The results have been saved." });
      }
    });
  };

  const handleSetBreaker = (playerId: string) => {
    if (isFinished) return;
    updateMatch.mutate({
      id: matchId,
      updates: { currentBreakerId: playerId }
    });
  };

  const p1Name = match.player1?.firstName || match.player1?.lastName ? `${match.player1.firstName} ${match.player1.lastName}` : "Player 1";
  const p2Name = match.player2 ? `${match.player2.firstName} ${match.player2.lastName}` : (match.player2Name || "Guest Player");

  const handleUpdateRating = (player: 'player1' | 'player2', rating: string) => {
    updateMatch.mutate({ 
      id: matchId, 
      updates: { 
        [`${player}Rating`]: rating,
        player1Score: 0, // Reset scores when rating changes to re-apply handicap
        player2Score: 0
      } 
    }, {
      onSuccess: (updatedMatch) => {
        const r1 = parseInt(updatedMatch.player1Rating || "0");
        const r2 = parseInt(updatedMatch.player2Rating || "0");
        if (!isNaN(r1) && !isNaN(r2)) {
          const d = r1 - r2;
          const p = Math.floor(Math.abs(d) / 40);
          updateMatch.mutate({
            id: matchId,
            updates: {
              player1Score: d > 0 ? -p : 0,
              player2Score: d < 0 ? -p : 0
            }
          });
        }
      }
    });
  };

  const handleUpdateTeam = (player: 'player1' | 'player2', team: string) => {
    updateMatch.mutate({
      id: matchId,
      updates: {
        [`${player}Team`]: team
      }
    });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-in fade-in duration-500 min-h-screen flex flex-col px-4">
      {/* Top Bar - Clocks and Controls */}
      <div className="flex flex-col items-center gap-6 py-6 sm:py-8">
        <div className="flex items-center justify-between w-full">
          <Link href="/">
            <Button variant="ghost" size="sm" className="hover:bg-muted h-9">
              <ArrowLeft className="w-4 h-4 mr-2" /> Dashboard
            </Button>
          </Link>
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => {
             navigator.clipboard.writeText(window.location.href);
             toast({ title: "Link Copied", description: "Match URL copied to clipboard" });
          }}>
            <Share2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex flex-col items-center gap-6 w-full max-w-md">
          <MatchClock 
            matchId={matchId} 
            elapsedSeconds={match.elapsedSeconds} 
            isPaused={match.isPaused} 
            lastActionAt={match.lastActionAt} 
            readOnly={isFinished}
          />

          {!isFinished && <ShotClock />}
          
          {isFinished && (
            <div className="px-8 py-3 bg-muted rounded-2xl font-display font-bold text-2xl tracking-widest text-muted-foreground border-2 border-border/50">
              FINAL SCORE
            </div>
          )}
        </div>
      </div>

      <div className="flex-grow" />

      {/* Players at bottom - Fixed Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end pb-32">
        {/* Player 1 */}
        <div className="w-full">
          <ScoreCard 
            player={match.player1 ? { ...match.player1, profileImageUrl: match.player1.profileImageUrl } : undefined} 
            customName={match.player1Name || undefined}
            rating={match.player1Rating || undefined}
            isGuest={false}
            score={match.player1Score} 
            isBreaker={match.currentBreakerId === match.player1Id}
            isWinner={isFinished && match.winnerId === match.player1Id}
            readOnly={isFinished}
            onIncrement={() => handleScoreChange('player1', 1)}
            onDecrement={() => handleScoreChange('player1', -1)}
            onSetBreaker={() => handleSetBreaker(match.player1Id)}
            onUpdateName={(name) => updateMatch.mutate({ id: matchId, updates: { player1Name: name } })}
            onUpdateTeam={(team) => handleUpdateTeam('player1', team)}
            onUpdateRating={(rating) => handleUpdateRating('player1', rating)}
            teamName={match.player1Team || undefined}
          />
        </div>

        {/* Player 2 */}
        <div className="w-full">
          <ScoreCard 
            player={match.player2 ? { ...match.player2, profileImageUrl: match.player2.profileImageUrl } : undefined} 
            customName={match.player2Name || undefined}
            teamName={match.player2Team || undefined}
            rating={match.player2Rating || undefined}
            isGuest={!match.player2Id}
            score={match.player2Score} 
            isBreaker={match.currentBreakerId === match.player2Id}
            isWinner={isFinished && match.winnerId === match.player2Id}
            readOnly={isFinished}
            onIncrement={() => handleScoreChange('player2', 1)}
            onDecrement={() => handleScoreChange('player2', -1)}
            onSetBreaker={() => handleSetBreaker(match.player2Id || "guest")}
            onUpdateName={(name) => updateMatch.mutate({ id: matchId, updates: { player2Name: name } })}
            onUpdateTeam={(team) => handleUpdateTeam('player2', team)}
            onUpdateRating={(rating) => handleUpdateRating('player2', rating)}
          />
        </div>
      </div>
    </div>
  );
}
